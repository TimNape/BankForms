﻿using System.Web.UI;

namespace BankForms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}