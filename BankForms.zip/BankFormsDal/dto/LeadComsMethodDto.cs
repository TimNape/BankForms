﻿using BankFormsDal.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankFormsDal.dto
{
    public class LeadComsMethodDto 
    {
        public long leadid { get; set; }
        public int comsMethodId { get; set; }
    }
}
