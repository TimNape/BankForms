﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankFormsDal.dto
{
    public class BankingRegionDto
    {
        public int id { get; set; }
        public string caption { get; set; }
    }
}
