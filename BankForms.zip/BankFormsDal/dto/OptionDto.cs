﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankFormsDal.dto
{
    public class OptionDto
    {
        public int value { get;  set; }
        public string text { get;  set; }
    }
}
