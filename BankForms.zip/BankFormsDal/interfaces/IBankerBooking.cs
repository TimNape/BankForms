﻿using BankFormsDal.dto;


namespace BankFormsDal.interfaces
{
    public interface IBankerBooking
    {
        BankerBookingDto getBankerBookingDto();
    }
}
