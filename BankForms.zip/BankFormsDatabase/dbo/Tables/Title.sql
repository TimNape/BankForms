﻿CREATE TABLE [dbo].[Title] (
    [Id]      INT          NOT NULL,
    [Caption] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Title] PRIMARY KEY CLUSTERED ([Id] ASC)
);

